/**
 * Classe représentant une tâche
 */
class Tache {
    constructor(description, statut = 'à faire') {
        this.id = Date.now() + Math.random(); // ID unique simple
        this.description = description;
        this.statut = statut;
        this.dateCreation = new Date();
    }

    /**
     * Marque la tâche comme terminée
     */
    terminer() {
        this.statut = 'terminée';
    }

    /**
     * Vérifie si la tâche est terminée
     * @returns {boolean}
     */
    estTerminee() {
        return this.statut === 'terminée';
    }

    /**
     * Retourne une représentation string de la tâche
     * @returns {string}
     */
    toString() {
        const statusIcon = this.estTerminee() ? '✅' : '❌';
        const dateStr = this.dateCreation.toLocaleDateString('fr-FR');
        return `${statusIcon} [${this.statut.toUpperCase()}] ${this.description} (créée le ${dateStr})`;
    }
}

module.exports = Tache;