const readline = require('readline');

/**
 * Classe pour gérer l'interface console
 */
class InterfaceConsole {
    constructor() {
        this.rl = readline.createInterface({
            input: process.stdin,
            output: process.stdout
        });
    }

    /**
     * Affiche un message
     * @param {string} message 
     */
    afficher(message) {
        console.log(message);
    }

    /**
     * Affiche le menu principal
     */
    afficherMenu() {
        console.log('\n' + '='.repeat(50));
        console.log('📝 GESTIONNAIRE DE TÂCHES PERSONNELLES');
        console.log('='.repeat(50));
        console.log('1. ➕ Ajouter une nouvelle tâche');
        console.log('2. ✅ Marquer une tâche comme terminée');
        console.log('3. 📋 Afficher toutes les tâches');
        console.log('4. 🔄 Afficher les tâches en cours');
        console.log('5. ✅ Afficher les tâches terminées');
        console.log('6. 🗑️  Supprimer une tâche');
        console.log('7. 📊 Afficher les statistiques');
        console.log('8. 🚪 Quitter');
        console.log('='.repeat(50));
    }

    /**
     * Demande une saisie à l'utilisateur
     * @param {string} question 
     * @returns {Promise<string>}
     */
    demanderSaisie(question) {
        return new Promise((resolve) => {
            this.rl.question(question, (response) => {
                resolve(response.trim());
            });
        });
    }

    /**
     * Affiche une liste de tâches avec numérotation
     * @param {Tache[]} taches 
     * @param {string} titre 
     */
    afficherTaches(taches, titre = 'Liste des tâches') {
        console.log(`\n📋 ${titre}`);
        console.log('-'.repeat(50));
        
        if (taches.length === 0) {
            console.log('   Aucune tâche à afficher');
            return;
        }

        taches.forEach((tache, index) => {
            console.log(`${index + 1}. ${tache.toString()}`);
        });
        console.log('-'.repeat(50));
    }

    /**
     * Affiche les statistiques
     * @param {object} stats 
     */
    afficherStatistiques(stats) {
        console.log('\n📊 STATISTIQUES');
        console.log('-'.repeat(30));
        console.log(`Total des tâches: ${stats.total}`);
        console.log(`Tâches terminées: ${stats.terminees}`);
        console.log(`Tâches en cours: ${stats.enCours}`);
        console.log(`Progression: ${stats.pourcentageTerminees}%`);
        
        // Barre de progression visuelle
        const barreLength = 20;
        const progression = Math.round((stats.pourcentageTerminees / 100) * barreLength);
        const barre = '█'.repeat(progression) + '░'.repeat(barreLength - progression);
        console.log(`[${barre}] ${stats.pourcentageTerminees}%`);
        console.log('-'.repeat(30));
    }

    /**
     * Ferme l'interface
     */
    fermer() {
        this.rl.close();
    }

    /**
     * Efface la console
     */
    effacerConsole() {
        console.clear();
    }
}

module.exports = InterfaceConsole;