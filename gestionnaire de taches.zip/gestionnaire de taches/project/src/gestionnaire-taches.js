const Tache = require('./tache');

/**
 * Classe pour gérer une liste de tâches
 */
class GestionnaireTaches {
    constructor() {
        this.taches = [];
    }

    /**
     * Ajoute une nouvelle tâche
     * @param {string} description - Description de la tâche
     * @returns {Tache} La tâche créée
     */
    ajouterTache(description) {
        if (!description || description.trim() === '') {
            throw new Error('La description de la tâche ne peut pas être vide');
        }

        const nouvelleTache = new Tache(description.trim());
        this.taches.push(nouvelleTache);
        return nouvelleTache;
    }

    /**
     * Marque une tâche comme terminée
     * @param {number} index - Index de la tâche dans la liste
     * @returns {boolean} True si la tâche a été marquée comme terminée
     */
    terminerTache(index) {
        if (index < 0 || index >= this.taches.length) {
            return false;
        }

        this.taches[index].terminer();
        return true;
    }

    /**
     * Supprime une tâche de la liste
     * @param {number} index - Index de la tâche à supprimer
     * @returns {boolean} True si la tâche a été supprimée
     */
    supprimerTache(index) {
        if (index < 0 || index >= this.taches.length) {
            return false;
        }

        this.taches.splice(index, 1);
        return true;
    }

    /**
     * Retourne toutes les tâches en cours (non terminées)
     * @returns {Tache[]} Liste des tâches en cours
     */
    getTachesEnCours() {
        return this.taches.filter(tache => !tache.estTerminee());
    }

    /**
     * Retourne toutes les tâches terminées
     * @returns {Tache[]} Liste des tâches terminées
     */
    getTachesTerminees() {
        return this.taches.filter(tache => tache.estTerminee());
    }

    /**
     * Retourne toutes les tâches
     * @returns {Tache[]} Liste de toutes les tâches
     */
    getToutesLesTaches() {
        return [...this.taches];
    }

    /**
     * Retourne le nombre total de tâches
     * @returns {number}
     */
    getNombreTaches() {
        return this.taches.length;
    }

    /**
     * Retourne des statistiques sur les tâches
     * @returns {object} Objet contenant les statistiques
     */
    getStatistiques() {
        const total = this.taches.length;
        const terminees = this.getTachesTerminees().length;
        const enCours = this.getTachesEnCours().length;

        return {
            total,
            terminees,
            enCours,
            pourcentageTerminees: total > 0 ? Math.round((terminees / total) * 100) : 0
        };
    }
}

module.exports = GestionnaireTaches;