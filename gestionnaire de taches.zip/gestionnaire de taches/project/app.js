const GestionnaireTaches = require('./src/gestionnaire-taches');
const InterfaceConsole = require('./src/interface-console');

/**
 * Application principale de gestion de tâches
 */
class AppGestionTaches {
    constructor() {
        this.gestionnaire = new GestionnaireTaches();
        this.interface = new InterfaceConsole();
        this.continuer = true;

        // Ajouter quelques tâches d'exemple
        this.ajouterTachesExemple();
    }

    /**
     * Ajoute quelques tâches d'exemple pour démonstration
     */
    ajouterTachesExemple() {
        try {
            this.gestionnaire.ajouterTache('Apprendre JavaScript');
            this.gestionnaire.ajouterTache('Faire les courses');
            this.gestionnaire.ajouterTache('Réviser pour l\'examen');
            
            // Marquer une tâche comme terminée pour l'exemple
            this.gestionnaire.terminerTache(1);
        } catch (error) {
            // Ignorer les erreurs lors de l'ajout des exemples
        }
    }

    /**
     * Démarre l'application
     */
    async demarrer() {
        this.interface.effacerConsole();
        this.interface.afficher('🎉 Bienvenue dans votre gestionnaire de tâches personnelles !');
        
        while (this.continuer) {
            try {
                this.interface.afficherMenu();
                const choix = await this.interface.demanderSaisie('\n👉 Choisissez une option (1-8): ');
                await this.traiterChoix(choix);
            } catch (error) {
                this.interface.afficher(`❌ Erreur: ${error.message}`);
            }
        }

        this.interface.afficher('\n👋 Au revoir ! Merci d\'avoir utilisé le gestionnaire de tâches.');
        this.interface.fermer();
    }

    /**
     * Traite le choix de l'utilisateur
     * @param {string} choix 
     */
    async traiterChoix(choix) {
        switch (choix) {
            case '1':
                await this.ajouterNouvelleTache();
                break;
            case '2':
                await this.marquerTacheTerminee();
                break;
            case '3':
                this.afficherToutesLesTaches();
                break;
            case '4':
                this.afficherTachesEnCours();
                break;
            case '5':
                this.afficherTachesTerminees();
                break;
            case '6':
                await this.supprimerTache();
                break;
            case '7':
                this.afficherStatistiques();
                break;
            case '8':
                this.continuer = false;
                break;
            default:
                this.interface.afficher('❌ Option invalide. Veuillez choisir entre 1 et 8.');
        }

        if (this.continuer && choix !== '8') {
            await this.interface.demanderSaisie('\n⏎ Appuyez sur Entrée pour continuer...');
            this.interface.effacerConsole();
        }
    }

    /**
     * Ajoute une nouvelle tâche
     */
    async ajouterNouvelleTache() {
        const description = await this.interface.demanderSaisie('\n📝 Entrez la description de la nouvelle tâche: ');
        
        if (!description) {
            this.interface.afficher('❌ La description ne peut pas être vide.');
            return;
        }

        try {
            const nouvelleTache = this.gestionnaire.ajouterTache(description);
            this.interface.afficher(`✅ Tâche ajoutée avec succès: "${nouvelleTache.description}"`);
        } catch (error) {
            this.interface.afficher(`❌ Erreur lors de l'ajout: ${error.message}`);
        }
    }

    /**
     * Marque une tâche comme terminée
     */
    async marquerTacheTerminee() {
        const tachesEnCours = this.gestionnaire.getTachesEnCours();
        
        if (tachesEnCours.length === 0) {
            this.interface.afficher('📭 Aucune tâche en cours à terminer.');
            return;
        }

        this.interface.afficherTaches(tachesEnCours, 'Tâches en cours');
        const choix = await this.interface.demanderSaisie('\n✅ Numéro de la tâche à marquer comme terminée: ');
        
        const index = parseInt(choix) - 1;
        const indexGlobal = this.gestionnaire.getToutesLesTaches().indexOf(tachesEnCours[index]);
        
        if (this.gestionnaire.terminerTache(indexGlobal)) {
            this.interface.afficher(`✅ Tâche "${tachesEnCours[index].description}" marquée comme terminée !`);
        } else {
            this.interface.afficher('❌ Numéro de tâche invalide.');
        }
    }

    /**
     * Affiche toutes les tâches
     */
    afficherToutesLesTaches() {
        const taches = this.gestionnaire.getToutesLesTaches();
        this.interface.afficherTaches(taches, 'Toutes les tâches');
    }

    /**
     * Affiche les tâches en cours
     */
    afficherTachesEnCours() {
        const tachesEnCours = this.gestionnaire.getTachesEnCours();
        this.interface.afficherTaches(tachesEnCours, 'Tâches en cours');
    }

    /**
     * Affiche les tâches terminées
     */
    afficherTachesTerminees() {
        const tachesTerminees = this.gestionnaire.getTachesTerminees();
        this.interface.afficherTaches(tachesTerminees, 'Tâches terminées');
    }

    /**
     * Supprime une tâche
     */
    async supprimerTache() {
        const taches = this.gestionnaire.getToutesLesTaches();
        
        if (taches.length === 0) {
            this.interface.afficher('📭 Aucune tâche à supprimer.');
            return;
        }

        this.interface.afficherTaches(taches, 'Liste des tâches');
        const choix = await this.interface.demanderSaisie('\n🗑️ Numéro de la tâche à supprimer: ');
        
        const index = parseInt(choix) - 1;
        
        if (index >= 0 && index < taches.length) {
            const tacheASupprimer = taches[index];
            const confirmation = await this.interface.demanderSaisie(
                `⚠️ Êtes-vous sûr de vouloir supprimer "${tacheASupprimer.description}" ? (oui/non): `
            );
            
            if (confirmation.toLowerCase() === 'oui' || confirmation.toLowerCase() === 'o') {
                if (this.gestionnaire.supprimerTache(index)) {
                    this.interface.afficher(`✅ Tâche "${tacheASupprimer.description}" supprimée avec succès !`);
                } else {
                    this.interface.afficher('❌ Erreur lors de la suppression.');
                }
            } else {
                this.interface.afficher('❌ Suppression annulée.');
            }
        } else {
            this.interface.afficher('❌ Numéro de tâche invalide.');
        }
    }

    /**
     * Affiche les statistiques
     */
    afficherStatistiques() {
        const stats = this.gestionnaire.getStatistiques();
        this.interface.afficherStatistiques(stats);
    }
}

// Point d'entrée de l'application
if (require.main === module) {
    const app = new AppGestionTaches();
    app.demarrer().catch(error => {
        console.error('Erreur fatale:', error);
        process.exit(1);
    });
}

module.exports = AppGestionTaches;